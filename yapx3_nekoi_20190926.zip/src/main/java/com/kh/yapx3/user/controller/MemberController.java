package com.kh.yapx3.user.controller;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.kh.yapx3.user.mail.GmailSend;
import com.kh.yapx3.user.model.service.MemberService;
import com.kh.yapx3.user.model.vo.Member;

@RequestMapping( "/user" )
@Controller
@SessionAttributes( "memberLoggedIn" )
public class MemberController {

	@Autowired
	MemberService ms;
	
	@Autowired
	BCryptPasswordEncoder passwordEncoder;
	
	Logger logger = LoggerFactory.getLogger( getClass() );
	
	@RequestMapping( "/loginClick.do" )
	public String loginClick() {
		logger.info( "loginClick" );
		
		return "user/loginClick";
	}
	
	@RequestMapping( "/loginForm.do" )
	public String loginForm() {
		logger.info( "loginForm" );
		return "user/loginForm";
	}
	
	@RequestMapping( "/loginFormEnd.do" )
	public String loginFormEnd( Member member,
								Model m ) {
		logger.debug( "회원가입 처리요청" );
		//0.비밀번호 암호화
		String rawPassword = member.getUserPassword();
		logger.debug( "암호화전 : " + rawPassword );
		String encodedPassword = passwordEncoder.encode(rawPassword);
		logger.debug( "암호화후 : " + encodedPassword );
		//member객체 대입
		member.setUserPassword(encodedPassword);
		//1.비지니스로직
		logger.debug( "member@memberEnrollEnd = " + member );
		int result = ms.insertMember( member );
		
		//2.view단처리
		m.addAttribute( "msg", result>0?"회원가입성공!":"회원가입실패!" );
		m.addAttribute( "loc", "/" );
		return "common/msg";
	}
	
	@RequestMapping( "/loginCheck.do" )
	public String loginCheck( @RequestParam String memberId,
							  @RequestParam String password,
							  Model m ){
		//1.업무로직: 회원정보 가져오기
		Member member = ms.selectOneMember( memberId );
		
		String msg = "";
		String loc = "/";
		
		//1-1.아이디가 존재하지 않는 경우
		if( member == null ) {
			msg = "아이디가 존재하지 않습니다.";
			loc = "/user/loginClick.do";
			
		}
		else {
			//1-2.로그인 성공
			if( passwordEncoder.matches( password, member.getUserPassword() ) ) {
				msg = "로그인 성공!";
				//memberLoggedIn 세션 속성에 지정
				//model에 지정된 속성은 requestScope속성에 담김
				
				m.addAttribute( "memberLoggedIn", member );
			}
			//1-3.비밀번호가 틀린 경우
			else {
				msg = "비밀번호가 틀립니다.";
				loc = "/user/loginClick.do";
			}
		}
		
		//2. view단 처리
		m.addAttribute( "msg", msg );
		m.addAttribute( "loc", loc );
		return "common/msg";
	}
	
	@ResponseBody
	@RequestMapping( "/checkIdDuplicate.do" )
	public Map<String,Object> checkIdDuplicate(@RequestParam String memberId ) {
		boolean isUsable = ms.selectOneMember(memberId) == null ? true : false;
		
		Map<String,Object> map = new HashMap<>();
		map.put( "isUsable", isUsable);
		
		return map;
	}
	
	@ResponseBody
	@RequestMapping( "/sendEmail.do" )
	public void sendEmail( @RequestParam String memberId ) {
		logger.info( "sendEmail:memberId={}", memberId );
		new GmailSend().GmailSet( memberId, "테스트메일", "이건 내용" );
	}

}
