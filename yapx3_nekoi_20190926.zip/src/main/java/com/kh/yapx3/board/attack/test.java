package com.kh.yapx3.board.attack;

public class test {

}
